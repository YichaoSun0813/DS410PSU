import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.util.LinkedList;
import java.util.Scanner;

public class database 
{
	private LinkedList<String> Fname = new LinkedList<String>();
	private LinkedList<String> Lname = new LinkedList<String>();
	private LinkedList<String> position = new LinkedList<String>();
	private LinkedList<Integer> points = new LinkedList<Integer>();
	private LinkedList<Integer> blocks = new LinkedList<Integer>();
	private LinkedList<Integer> rebounds = new LinkedList<Integer>();
	private LinkedList<Integer> steals = new LinkedList<Integer>();
	private LinkedList<Integer> assists = new LinkedList<Integer>();
	private LinkedList<Integer> SDef = new LinkedList<Integer>();
	private LinkedList<Integer> FDef = new LinkedList<Integer>();
	private LinkedList<Integer> MVP = new LinkedList<Integer>();
	private LinkedList<Integer> FMVP = new LinkedList<Integer>();
	private LinkedList<Double> PER = new LinkedList<Double>();
	private LinkedList<Double> playoff = new LinkedList<Double>();
	private LinkedList<Double> HChampions = new LinkedList<Double>();
	private LinkedList<Double> FChampions = new LinkedList<Double>();	
	private LinkedList<Integer> FTeams = new LinkedList<Integer>();	
	private LinkedList<Integer> STeams = new LinkedList<Integer>();	
	private LinkedList<Integer> TTeams = new LinkedList<Integer>();	
	
	int amount = 0;
			
	public void addAPlayer(String Fname1, String Lname1, String position1, int points1, int blocks1, int rebounds1, int steals1, int assists1,  
			               double PER1, int SDef1, int FDef1,  int MVP1, int FMVP1, int TTeams1, int STeams1, int FTeams1,
			               double playoff1, double HChampions1, double FChampions1)
	{
		Fname.add(Fname1); 
		Lname.add(Lname1); 
		position.add(position1); 
		points.add(points1);
		blocks.add(blocks1);
		rebounds.add(rebounds1);
		steals.add(steals1);
		assists.add(assists1);
		PER.add(PER1);
		SDef.add(SDef1);
		FDef.add(FDef1);
		MVP.add(MVP1);
		FMVP.add(FMVP1);
		playoff.add(playoff1);
		HChampions.add(HChampions1);
		FChampions.add(FChampions1);
		FTeams.add(FTeams1);
		STeams.add(STeams1);
		TTeams.add(TTeams1);
		
		amount++;	
	}
	
	public void deletePlayer()
	{
		@SuppressWarnings("resource")
		Scanner remove = new Scanner(System.in);
		
		printPlayer();
		System.out.println();
		System.out.print("Input order, which one do you want to remove: ");
		int order = remove.nextInt();
		
		while (order <= 0 || order > amount+1)
		{
			System.out.print("Invalid input, re-enter: ");
			order = remove.nextInt();
		}

		order--;
		
		Fname.remove(order);  
		Lname.remove(order); 
		position.remove(order); 
		points.remove(order); 
		blocks.remove(order); 
		rebounds.remove(order); 
		steals.remove(order); 
		assists.remove(order); 
		PER.remove(order); 
		SDef.remove(order); 
		FDef.remove(order); 
		MVP.remove(order); 
		FMVP.remove(order); 
		playoff.remove(order); 
		HChampions.remove(order); 
		FChampions.remove(order); 
		FTeams.remove(order);
		STeams.remove(order);
		TTeams.remove(order);
		
		amount--;	
	}
	
	public void printPlayer()
	{
		    System.out.printf( "%-5s %-20s %-20s %-10s %-6s %-6s %-8s %-6s %-7s %-5s %-13s %-13s %-3s %-4s %-12s %-12s %-12s %-7s %-13s %-14s %n",  
		    					"Order", "First Name", "Last Name", "Position",
		    					"Points", "Blocks", "Rebounds", "Steals", "Assists", "PER", 
		    					"2nd Defensive", "1st Defensive", "MVP", "FMVP", "Third Team", "Second Team", "First Team", "Playoff", "Half Champion", "Final Champion");			
	
		    for (int i = 0; i < amount; i++)
		    {
			    System.out.printf( "%-5s %-20s %-20s %-10s %-6s %-6s %-8s %-6s %-7s %-5s %-13s %-13s %-3s %-4s %-12s %-12s %-12s %-7s %-13s %-14s %n",  
			    				    i+1, Fname.get(i), Lname.get(i), position.get(i), points.get(i), blocks.get(i), rebounds.get(i), steals.get(i), assists.get(i),
			    				    PER.get(i), SDef.get(i), FDef.get(i), MVP.get(i), FMVP.get(i), TTeams.get(i), STeams.get(i), FTeams.get(i),
			    				    playoff.get(i), HChampions.get(i), FChampions.get(i)
			    				    );
		    }
	}
	
	public void makeRanking()
	{
		@SuppressWarnings("resource")
		Scanner choose = new Scanner(System.in);
		
		weight w = new weight();
		ranking r = new ranking();
		
		System.out.print("Do you want to customize a formula (Y/N)? ");
		char choice = choose.next().charAt(0);
		
		while(choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n')
		{
			System.out.print("Invalid input, re-enter: ");
			choice = choose.next().charAt(0);
		}
		
		System.out.println();
		
		if (choice == 'Y' || choice == 'y')
		{
			w.userDefinedWeight();
		}
		else
		{
			w.defaultWeight();
		}
		
		for (int i = 0; i < amount; i++)
		{	
			double score = w.calculation(points.get(i), blocks.get(i), rebounds.get(i), steals.get(i), assists.get(i), PER.get(i), SDef.get(i), FDef.get(i), 
					MVP.get(i), FMVP.get(i),TTeams.get(i),STeams.get(i),FTeams.get(i), playoff.get(i), HChampions.get(i), FChampions.get(i));
			r.addPlayers(Fname.get(i), Lname.get(i), position.get(i),score);	
		}
		
		r.rank();
		r.result();
	}
}

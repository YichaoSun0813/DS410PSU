import java.util.Scanner;

public class weight 
{
	private double weightForPer = -1;
	private int weightForMVP = -1;
	private int weightForFMVP = -1;
	private int weightForDef = -1;
	private int weightForChampion = -1;
	private int weightForTeam = -1;

	public void defaultWeight()
	{
		weightForPer = 90;
		weightForMVP = 3;
		weightForFMVP = 3;
		weightForChampion = 3;
		weightForDef = 3;	
		weightForTeam = 3;
	}
	
	public void userDefinedWeight()
	{
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		
		System.out.print("Setting the weight of percentage for the PER (0-100): ");
		weightForPer = input.nextDouble();
		while (weightForPer < 0 || weightForPer > 100)
		{
			System.out.print("Invalid input, re-enter: ");
			weightForPer = input.nextDouble();
		}
		System.out.print("OK, just remind you that the weight of percentage for total data will be " + (100 - weightForPer) + "%");
		System.out.println();
		
		System.out.print("How important the MVP is (1-5) (5 is the most important)? ");
		weightForMVP = input.nextInt();
		while (weightForMVP != 1 && weightForMVP != 2 && weightForMVP != 3 && weightForMVP != 4 && weightForMVP != 5)
		{
			System.out.print("Invalid input, re-enter: ");
			weightForMVP = input.nextInt();
		}
		System.out.println();
		
		System.out.print("How important the FMVP is (1-5)? ");
		weightForFMVP = input.nextInt();
		while (weightForFMVP != 1 && weightForFMVP != 2 && weightForFMVP != 3 && weightForFMVP != 4 && weightForFMVP != 5)
		{
			System.out.print("Invalid input, re-enter: ");
			weightForFMVP = input.nextInt();
		}
		System.out.println();
		
		System.out.print("How important the defense award is (1-5)? ");
		weightForDef = input.nextInt();
		while (weightForDef != 1 && weightForDef != 2 && weightForDef != 3 && weightForDef != 4 && weightForDef != 5)
		{
			System.out.print("Invalid input, re-enter: ");
			weightForDef = input.nextInt();
		}
		System.out.println();
		
		System.out.print("How important the championship is (1-5)? ");
		weightForChampion = input.nextInt();
		while (weightForChampion != 1 && weightForChampion != 2 && weightForChampion != 3 && weightForChampion != 4 && weightForChampion != 5)
		{
			System.out.print("Invalid input, re-enter: ");
			weightForChampion = input.nextInt();
		}
		System.out.println();	
		
		System.out.print("How important the All-NBA teams is (1-5)? ");
		weightForTeam = input.nextInt();
		while (weightForTeam != 1 && weightForTeam != 2 && weightForTeam != 3 && weightForTeam != 4 && weightForTeam != 5)
		{
			System.out.print("Invalid input, re-enter: ");
			weightForTeam = input.nextInt();
		}
		System.out.println();	
	}
	
	public double calculation(int point, int block, int rebound, int steal, int assist, double PER, int SDef, 
			int FDef, int MVP, int FMVP,int TTeam, int STeam, int FTeam, double playoff, double HChampion, double FChampion)
	{
		double finalScore;
		int total = point + assist + rebound + block + steal * 2;
		
		finalScore = (100 - (27.91 - PER) / 0.59) * (weightForPer / 100) + (total * 100 / 66996) * ((100 - weightForPer) / 100);		
	    finalScore += SDef * 0.5 * weightForDef / 6 + FDef * weightForDef / 6;
		finalScore += FMVP * weightForFMVP / 3 * 3 + MVP * weightForMVP / 3 * 3;
		finalScore += ((playoff - HChampion) * 7 / 8 + (HChampion - FChampion) * 14 + FChampion * 29) * weightForChampion / 30;
		finalScore += ((FTeam - MVP) / 3 * 2 + STeam / 3 * 1.5 + TTeam / 3 * 1) * weightForTeam;
		
		return finalScore;
	}
}
import java.util.LinkedList;

public class ranking 
{
	private LinkedList<String> Fname = new LinkedList<String>();
	private LinkedList<String> Lname = new LinkedList<String>();
	private LinkedList<String> position = new LinkedList<String>();
	private LinkedList<Double> score = new LinkedList<Double>();
	private int amount = 0;
	
	public void addPlayers(String Fname1, String Lname1, String position1, double score1)
	{
		Fname.add(Fname1); 
		Lname.add(Lname1); 
		position.add(position1); 
		score.add(score1);
		amount++;
	}
	
	public void rank()
	{
		for (int i = 0; i < amount; i++)
		{
			for (int j = i + 1; j < amount; j++)
			{
				if (score.get(j) > score.get(i))
				{
					 String tempFname = new String(Fname.get(i));
					 String tempLname = new String(Lname.get(i));
					 String tempPos = new String(position.get(i));
					 double tempScore = score.get(i);
					 
					 Fname.set(i, Fname.get(j));
					 Lname.set(i, Lname.get(j));
					 position.set(i, position.get(j));
					 score.set(i, score.get(j));
					 
					 Fname.set(j, tempFname);
					 Lname.set(j, tempLname);
					 position.set(j, tempPos);
					 score.set(j, tempScore);
				}
			}
		}
	}
	
	public void result()
	{
		double highest = score.get(0);
		
		System.out.printf( "%-5s %-20s %-20s %-10s %-5s %n","Rank", "First Name", "Second Name", "Position", "Score");	
	    for (int i = 0; i < amount; i++)
	    {
	    	String newScore = String.format("%.2f", score.get(i) * 100 / highest + (100 - (score.get(i) * 100 / highest)) * 0.8);
		    System.out.printf( "%-5s %-20s %-20s %-10s %-5s %n", i+1, Fname.get(i), Lname.get(i), position.get(i), newScore);
	    }
	}
}

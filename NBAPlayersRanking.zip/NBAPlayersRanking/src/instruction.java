public class instruction 
{
	public void instructions()
	{
		System.out.println("This NBA player ranking system will only take the following data as factors");
		System.out.println("-- Player Efficiency Rating (PER)");
		System.out.println("-- Total points/blocks/rebounds/steals/assists (TP/TB/TR/TS/TA integrated as TD)");
		System.out.println("-- NBA All-Defensive First/Second Team award (FDA/SDA)");
		System.out.println("-- MVP FMVP (MVP/FMVP)");
		System.out.println("-- How many time the team for the player appearance in playoff? (PT)");
		System.out.println("-- West/East Championship Final Chanpionship (HC/FC)");
		System.out.println("-- All-NBA First/Second/Third Team (FT/ST/TT)");
		System.out.println();
		
		System.out.println("The formula for calculation will be basic scores + extra scores = final score");
		System.out.println("Basic score = PER + TD (Max 100 points)");
		System.out.println("Extra score = FDA + SDA + MVP + FMVP + PT + HC + FC + FT + ST + TT");
		System.out.println();
		
		System.out.println("Pay attention:");
		System.out.println("1 The true value for the championship all times will be balanced");
		System.out.println("2 For players lacking TB and TS, the system will directly simulate these two data");
		System.out.println("3 Current players will have a higher score in the future");
		System.out.println("4 Current players will have a lower PER because the league has a higher defensive penalty limit");
		System.out.println("5 If you favourite NBA players is not in the list, you can input the information to rank him in the list");
		System.out.println();
	}
}

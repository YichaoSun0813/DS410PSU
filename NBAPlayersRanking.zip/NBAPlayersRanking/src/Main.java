import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		System.out.println("Welcome!");
		System.out.println();
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
		String connectionUrl = "jdbc:sqlserver://LAPTOP-I298A3T0;database=NBA;integratedSecurity=true;";  
		JOptionPane.showMessageDialog(null,"Successful to import the player's data from database"); 

		database d = new database();
		try (Connection con = DriverManager.getConnection(connectionUrl); Statement stmt = con.createStatement();) 
		{
		    String SQL = "SELECT * FROM Players";
		    ResultSet rs = stmt.executeQuery(SQL);

		    while (rs.next()) 
		    {
			   d.addAPlayer(rs.getString("FName"),rs.getString("LName"), rs.getString("Position"),rs.getInt("TPoints"), rs.getInt("TBlocks"), rs.getInt("TRebounds"), rs.getInt("TSteals"), rs.getInt("TAssists"),
			    		     rs.getDouble("PER"), rs.getInt("SDefense"), rs.getInt("FDefense"), rs.getInt("MVP"), rs.getInt("FMVP"), 
			    		     rs.getInt("Tteam"),rs.getInt("Steam"),rs.getInt("Fteam"),rs.getDouble("Playoff"), rs.getDouble("HChampion"), rs.getDouble("FChampion")
			    		     ); 		
		    }
		    System.out.println();
		}
		catch (SQLException e) 
		{
		    e.printStackTrace();
		}
		
		int choice = 0;
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		
		while (choice != 6)
		{
			choice = 0;
			while (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 && choice != 6)
			{
				System.out.println("1 View instruction");
				System.out.println("2 Add a NBA player");
				System.out.println("3 Delete a NBA player");
				System.out.println("4 View all players data");
				System.out.println("5 Ranking now!");
				System.out.println("6 Quit");
				System.out.println();
				System.out.print("Enter your choice: ");
				choice = input.nextInt();
				System.out.println();
			}
			
			if (choice == 1)
			{
				instruction i = new instruction();
				i.instructions();
			}
			else if (choice == 2)
			{
				@SuppressWarnings("resource")
				Scanner inputPlayer = new Scanner(System.in);
				
				System.out.print("What is the first name: ");
				String newFname = inputPlayer.nextLine();
				System.out.print("What is the last name: ");
				String newLname = inputPlayer.nextLine();
				System.out.print("What is the position: ");
				String newPosition = inputPlayer.nextLine();	
				while (!(newPosition.equals("C") || newPosition.equals("PF") || newPosition.equals("SF") || newPosition.equals("SG") || newPosition.equals("PG")))
				{
					System.out.print("Invaid input, please re-enter: ");
					newPosition = inputPlayer.nextLine();
				}
				
				System.out.print("What is the total points: ");
				int newPoints = inputPlayer.nextInt();
				System.out.print("What is the total blocks: ");
				int newBlocks = inputPlayer.nextInt();
				System.out.print("What is the total rebounds: ");
				int newRebounds = inputPlayer.nextInt();
				System.out.print("What is the total steals: ");
				int newSteals = inputPlayer.nextInt();
				System.out.print("What is the total assists: ");
				int newAssists = inputPlayer.nextInt();
				System.out.print("What is the PER: ");
				double newPER = inputPlayer.nextDouble();
				
				System.out.print("How many times for the all-defensive second Team awards?: ");
				int newSDef = inputPlayer.nextInt();
				while (newSDef < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newSDef = inputPlayer.nextInt();
				}
				System.out.print("How many times for the all-defensive first Team awards?: ");
				int newFDef = inputPlayer.nextInt();
				while (newFDef < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newFDef = inputPlayer.nextInt();
				}		
				
				System.out.print("How many MVPs?: ");
				int newMVP = inputPlayer.nextInt();
				while (newMVP < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newMVP = inputPlayer.nextInt();
				}
				System.out.print("How many FMVPs?: ");
				
				int newFMVP = inputPlayer.nextInt();
				while (newFMVP < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newFMVP = inputPlayer.nextInt();
				}		
				
				System.out.print("How many times the team for the player appearance in playoff?: ");
				double newPlayeroff = inputPlayer.nextDouble();
				while (newPlayeroff < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newPlayeroff = inputPlayer.nextDouble();
				}	
				
				System.out.print("How many east/west championships?: ");
				double newHChampion = inputPlayer.nextDouble();
				while (newHChampion < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newHChampion = inputPlayer.nextDouble();
				}	
				
				System.out.print("How many final championships?: ");
				double newFChampion = inputPlayer.nextDouble();
				while (newFChampion < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newFChampion = inputPlayer.nextDouble();
				}	
				
				System.out.print("How many All NBA first teams?: ");
				int newFteam = inputPlayer.nextInt();
				while (newFteam < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newFteam = inputPlayer.nextInt();
				}
				
				System.out.print("How many All NBA second teams?: ");
				int newSteam = inputPlayer.nextInt();
				while (newSteam  < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newSteam = inputPlayer.nextInt();
				}
				
				System.out.print("How many All NBA thrid teams?: ");
				int newTteam = inputPlayer.nextInt();
				while (newTteam < 0)
				{
					System.out.print("Invaid input, please re-enter: ");
					newTteam = inputPlayer.nextInt();
				}
				
				System.out.println();
				
				d.addAPlayer(newFname, newLname, newPosition, newPoints,  newBlocks, newRebounds, newSteals, newAssists, newPER, newSDef, 
						newFDef, newMVP, newFMVP, newTteam,newSteam,newFteam,newPlayeroff, newHChampion, newFChampion);

				System.out.println(); 
			}
			else if (choice == 3)
			{
				d.deletePlayer();
				System.out.println(); 
			}
			else if (choice == 4)
			{
				d.printPlayer();
				System.out.println(); 
			}
			else if (choice == 5)
			{
				d.makeRanking();
				System.out.println(); 
			}
			else if (choice == 6)
			{
				System.out.println("End of program");
			}
		}
	}
}
